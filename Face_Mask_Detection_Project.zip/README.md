
# Face Mask Detection Using Deep Learning

## Overview
This project uses a Convolutional Neural Network (CNN) and OpenCV to detect whether a person is wearing a mask in real-time from a webcam.

## Folder Structure
```
FaceMaskDetection/
│
├── dataset/
│   ├── with_mask/        # Add images of people wearing masks
│   └── without_mask/     # Add images of people without masks
│
├── train_mask_detector.py       # Script to train the model
├── real_time_detection.py       # Script to run real-time detection using webcam
├── README.md                    # Project documentation
└── .gitignore                   # Files to ignore in Git
```

## Requirements
- Python 3.x
- TensorFlow
- OpenCV
- NumPy
- imutils
- matplotlib

## Instructions
1. Add your dataset into the respective folders.
2. Run `train_mask_detector.py` to train the model.
3. Run `real_time_detection.py` to use the webcam for real-time face mask detection.

## License
MIT License
