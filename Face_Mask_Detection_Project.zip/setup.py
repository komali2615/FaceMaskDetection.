from setuptools import setup, find_packages

setup(
    name='face-mask-detection',
    version='1.0',
    description='A deep learning project to detect face masks using webcam and CNN.',
    author='Your Name',
    author_email='your.email@example.com',
    packages=find_packages(),
    install_requires=[
        'tensorflow>=2.0.0',
        'opencv-python',
        'imutils',
        'matplotlib',
        'numpy',
    ],
    python_requires='>=3.6',
)